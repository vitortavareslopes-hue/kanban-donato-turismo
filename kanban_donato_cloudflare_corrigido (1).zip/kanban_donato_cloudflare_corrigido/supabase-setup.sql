-- Execute no SQL Editor do SEU projeto Supabase.
-- Cria uma tabela isolada para o Kanban; não modifica tabelas existentes.
create table if not exists public.kanban_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text not null default '',
  status text not null default 'afazer' check (status in ('ideias','afazer','andamento','aguardando','concluido')),
  category text not null default '',
  priority text not null default 'Média' check (priority in ('Baixa','Média','Alta','Urgente')),
  assignee text not null default '',
  due_date date,
  tour text not null default '',
  tags text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.kanban_tasks enable row level security;
drop policy if exists "Users can read own Kanban tasks" on public.kanban_tasks;
create policy "Users can read own Kanban tasks" on public.kanban_tasks for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can insert own Kanban tasks" on public.kanban_tasks;
create policy "Users can insert own Kanban tasks" on public.kanban_tasks for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update own Kanban tasks" on public.kanban_tasks;
create policy "Users can update own Kanban tasks" on public.kanban_tasks for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete own Kanban tasks" on public.kanban_tasks;
create policy "Users can delete own Kanban tasks" on public.kanban_tasks for delete to authenticated using (auth.uid() = user_id);
create index if not exists kanban_tasks_user_id_created_at_idx on public.kanban_tasks(user_id, created_at desc);
