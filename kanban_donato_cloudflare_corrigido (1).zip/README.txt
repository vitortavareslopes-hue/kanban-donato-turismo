# Kanban Donato Turismo — versão gratuita Cloudflare Pages + Supabase

Esta pasta contém uma versão independente do Kanban com login, CRUD na nuvem, filtros, movimentação de colunas e backup JSON. O banco foi preparado no Supabase; falta publicar os arquivos no Cloudflare Pages para gerar o endereço público.

## 1. Configurar o banco
1. O banco já foi preparado no projeto Supabase Donato Turismo Financeiro com uma tabela isolada chamada `kanban_tasks`; as tabelas financeiras existentes não foram alteradas. A URL e a chave publicável já estão configuradas no `index.html`.
2. Abra SQL Editor e execute todo o conteúdo de `supabase-setup.sql`.
3. Em Project Settings → API, copie o Project URL e a chave publicável (`sb_publishable_...`, ou a chave `anon` legada).
4. A URL e a chave publicável já foram preenchidas no `index.html`. A chave é publicável e foi feita para uso no navegador; nunca coloque `service_role` ou secret key no arquivo.
5. Em Authentication → Providers / Email, mantenha e-mail/senha habilitado. Configure o endereço publicado na lista de URLs de redirecionamento se necessário.

## 2. Publicar sem custo no Cloudflare Pages
1. Acesse https://dash.cloudflare.com/ e crie uma conta gratuita.
2. Vá em Workers & Pages → Create → Pages → Direct Upload (ou Upload assets).
3. Faça upload do arquivo `index.html` (pode extrair o ZIP e enviar a pasta/arquivo conforme a tela aceitar).
4. Publique. O Cloudflare fornecerá um endereço `pages.dev`.
5. Abra o endereço, crie sua conta e confirme o e-mail se solicitado. Use o mesmo login no computador e celular.

## 3. Importar tarefas existentes
No Kanban antigo, clique em “Exportar backup” para baixar o JSON. Na nova versão, entre com sua conta, clique em “Importar backup” e selecione o arquivo. Revise as tarefas importadas.

## Observações
- O frontend é estático e usa Supabase Auth + Postgres para sincronizar as tarefas entre dispositivos.
- O SQL habilita Row Level Security para cada usuário acessar somente suas tarefas.
- O plano gratuito tem limites e políticas que podem mudar; projetos gratuitos do Supabase podem pausar após inatividade. Confira as condições atuais antes de depender dele para operação crítica.
- Esta versão inicial é independente; ainda não foi publicada na sua conta Cloudflare porque não tenho acesso autenticado à sua conta Cloudflare.
